<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("replace into `tomoe_character` values('21821','㘨','13864',NULL,'http://www.zdic.net/zd/zi2/ZdicE3Zdic98ZdicA8.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('24868','䍧','17255',NULL,'http://www.zdic.net/zd/zi2/ZdicE4Zdic8DZdicA7.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('8844','炋','28811',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic82Zdic8B.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9055','煞','29022',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85Zdic9E.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('9057','煠','29024',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA0.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9106','熑','29073',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic91.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50774','𥫣','154339',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicABZdicA3.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9086','煽','29053',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicBD.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('9101','熌','29068',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic8C.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9061','煤','29028',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA4.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('50240','𥣍','153805',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA3Zdic8D.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('51563','𥷸','155128',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicB7ZdicB8.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('50824','𥬕','154389',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicACZdic95.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9073','煰','29040',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicB0.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9074','煱','29041',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicB1.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('40167','𣅴','143732',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA3Zdic85ZdicB4.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('50371','𥥐','153936',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA5Zdic90.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('50049','𥠎','153614',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA0Zdic8E.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9062','煥','29029',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA5.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9065','煨','29032',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA8.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('9067','煪','29034',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicAA.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9089','熀','29056',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic80.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50503','𥧔','154068',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA7Zdic94.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('50909','𥭪','154474',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicADZdicAA.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9063','煦','29030',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA6.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('9064','照','29031',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA7.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('50538','𥧷','154103',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA7ZdicB7.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9349','犄','29316',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic8AZdic84.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('24759','䋺','17146',NULL,'http://www.zdic.net/zd/zi2/ZdicE4Zdic8BZdicBA.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('9093','熄','29060',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic84.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('9066','煩','29033',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicA9.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50624','𥩍','154189',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA9Zdic8D.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('11946','粩','31913',NULL,'http://www.zdic.net/zd/zi/ZdicE7ZdicB2ZdicA9.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50642','𥩟','154207',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA9Zdic9F.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9090','熁','29057',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic81.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50955','𥮘','154520',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicAEZdic98.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9072','煯','29039',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicAF.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9347','犂','29314',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic8AZdic82.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9069','煬','29036',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic85ZdicAC.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9547','獊','29514',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic8DZdic8A.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9097','熈','29064',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic88.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('52858','𦌇','156423',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA6Zdic8CZdic87.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('13109','脴','33076',NULL,'http://www.zdic.net/zd/zi/ZdicE8Zdic84ZdicB4.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50363','𥥈','153928',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicA5Zdic88.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9134','熭','29101',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86ZdicAD.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9094','熅','29061',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic85.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('50818','𥬏','154383',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicACZdic8F.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9098','熉','29065',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic89.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9100','熋','29067',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic8B.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('4539','徺','24506',NULL,'http://www.zdic.net/zd/zi/ZdicE5ZdicBEZdicBA.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('25191','䒪','17578',NULL,'http://www.zdic.net/zd/zi2/ZdicE4Zdic92ZdicAA.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('4144','帯','24111',NULL,'http://www.zdic.net/zd/zi/ZdicE5ZdicB8ZdicAF.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9096','熇','29063',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic87.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('18179','锂','38146',NULL,'http://www.zdic.net/zd/zi/ZdicE9Zdic94Zdic82.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('11408','窏','31375',NULL,'http://www.zdic.net/zd/zi/ZdicE7ZdicAAZdic8F.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9102','熍','29069',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic8D.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9121','熠','29088',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86ZdicA0.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('9119','熞','29086',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic9E.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9099','熊','29066',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic8A.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('51275','𥳘','154840',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicB3Zdic98.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9108','熓','29075',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic93.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('21575','㔲','13618',NULL,'http://www.zdic.net/zd/zi2/ZdicE3Zdic94ZdicB2.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('22294','㥙','14681',NULL,'http://www.zdic.net/zd/zi2/ZdicE3ZdicA5Zdic99.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('50984','𥮵','154549',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA5ZdicAEZdicB5.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('9115','熚','29082',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic9A.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9116','熛','29083',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic9B.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9104','熏','29071',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic8F.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('21832','㘳','13875',NULL,'http://www.zdic.net/zd/zi2/ZdicE3Zdic98ZdicB3.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('9124','熣','29091',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86ZdicA3.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9117','熜','29084',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic9C.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('5942','攵','25909',NULL,'http://www.zdic.net/zd/zi/ZdicE6Zdic94ZdicB5.htm',NULL,NULL,'0','-1','-1','2');");
E_D("replace into `tomoe_character` values('9107','熒','29074',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic92.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9114','熙','29081',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic99.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('40231','𣆴','143796',NULL,'http://www.zdic.net/zd/zi3/ZdicF0ZdicA3Zdic86ZdicB4.htm',NULL,NULL,'0','-1','-1','5');");
E_D("replace into `tomoe_character` values('25216','䓃','17603',NULL,'http://www.zdic.net/zd/zi2/ZdicE4Zdic93Zdic83.htm',NULL,NULL,'0','-1','-1','4');");
E_D("replace into `tomoe_character` values('4292','廃','24259',NULL,'http://www.zdic.net/zd/zi/ZdicE5ZdicBBZdic83.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9118','熝','29085',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic9D.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9122','熡','29089',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86ZdicA1.htm',NULL,NULL,'0','-1','-1','3');");
E_D("replace into `tomoe_character` values('9120','熟','29087',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86Zdic9F.htm',NULL,NULL,'0','-1','-1','1');");
E_D("replace into `tomoe_character` values('9127','熦','29094',NULL,'http://www.zdic.net/zd/zi/ZdicE7Zdic86ZdicA6.htm',NULL,NULL,'0','-1','-1','3');");

require("../../inc/footer.php");
?>